package com.fizzbuzz.FizzBuzz;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FizzBuzzApplicationTests {

	@Test
	void contextLoads() {
	}

	@Mock
	private Map<String, Integer> requestCounts;

	@InjectMocks
	private FizzBuzzService fizzBuzzService;

	@BeforeEach
	void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	void generateFizzBuzz_ReturnsCorrectResult() {

		FizzBuzzResponse response = fizzBuzzService.generateFizzBuzz(new FizzBuzzRequest(3, 5, 15, "Fizz", "Buzz"));
		List<String> result = response.getResult();
		System.out.println(result);
		assertEquals(15, result.size());
		assertEquals("1", result.get(0));
		assertEquals("2", result.get(1));
		assertEquals("Fizz", result.get(2));
		assertEquals("4", result.get(3));
		assertEquals("Buzz", result.get(4));
		assertEquals("FizzBuzz", result.get(14));
	}

	@Test
    void getStatistics_ReturnsCorrectStatistics() {
        when(requestCounts.entrySet()).thenReturn(Set.of(
                Map.entry("3-5-Fizz-Buzz", 5),
                Map.entry("2-7-Foo-Bar", 8),
                Map.entry("4-6-Baz-Qux", 3)
        ));

        FizzBuzzStatistics statistics = fizzBuzzService.getStatistics();

        assertEquals("2-7-Foo-Bar", statistics.getMostUsedRequest());
        assertEquals(8, statistics.getNumberOfHits());
    }

	@Test
    void getStatistics_NoRequests_ReturnsDefaultStatistics() {
        when(requestCounts.entrySet()).thenReturn(Set.of());

        FizzBuzzStatistics statistics = fizzBuzzService.getStatistics();

        assertEquals(null, statistics.getMostUsedRequest());
        assertEquals(0, statistics.getNumberOfHits());
    }

	@Test
	void updateStatistics_IncrementsHitCount() {
		fizzBuzzService.updateStatistics(new FizzBuzzRequest(3, 5, 15, "Fizz", "Buzz"));
		fizzBuzzService.updateStatistics(new FizzBuzzRequest(3, 5, 15, "Fizz", "Buzz"));

		verify(requestCounts, times(2)).put(eq("3-5-Fizz-Buzz"), anyInt());
		verify(requestCounts).put("3-5-Fizz-Buzz", 2);
	}
}
