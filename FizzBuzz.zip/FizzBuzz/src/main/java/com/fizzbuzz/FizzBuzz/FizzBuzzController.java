package com.fizzbuzz.FizzBuzz;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/fizzbuzz")
public class FizzBuzzController {
	private final FizzBuzzService fizzBuzzService;

	@Autowired
	public FizzBuzzController(FizzBuzzService fizzBuzzService) {
		this.fizzBuzzService = fizzBuzzService;
	}

	@PostMapping
	public FizzBuzzResponse fizzBuzz(@RequestBody FizzBuzzRequest rizzBuzzRequest) {
		return fizzBuzzService.generateFizzBuzz(rizzBuzzRequest);
	}

	@GetMapping("/statistics")
	public FizzBuzzStatistics getStatistics() {
		return fizzBuzzService.getStatistics();
	}
}
