package com.fizzbuzz.FizzBuzz;

import java.util.List;

public class FizzBuzzResponse {
	private List<String> result;

	public FizzBuzzResponse(List<String> result) {
		this.result = result;
	}

	public List<String> getResult() {
		return result;
	}
}
