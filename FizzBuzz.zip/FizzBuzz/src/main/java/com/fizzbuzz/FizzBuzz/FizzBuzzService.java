package com.fizzbuzz.FizzBuzz;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.springframework.stereotype.Service;

@Service
public class FizzBuzzService {
	private Map<String, Integer> requestCounts;
	
	public FizzBuzzService(Map<String, Integer> requestCounts) {
		this.requestCounts = requestCounts;
	}

	public FizzBuzzResponse generateFizzBuzz(FizzBuzzRequest fizzBuzzRequest) {
		List<String> result = IntStream.range(1, fizzBuzzRequest.getLimit()).mapToObj(v -> {
			if (v % (fizzBuzzRequest.getInt1() * fizzBuzzRequest.getInt2()) == 0) {
				return fizzBuzzRequest.getStr1() + fizzBuzzRequest.getStr2();
			} else if (v % fizzBuzzRequest.getInt1() == 0) {
				return fizzBuzzRequest.getStr1();
			} else if (v % fizzBuzzRequest.getInt2() == 0) {
				return fizzBuzzRequest.getStr2();
			} else {
				return String.valueOf((int)v);
			}
		}).collect(Collectors.toList());

		updateStatistics(fizzBuzzRequest);
		return new FizzBuzzResponse(result);
	}

	public FizzBuzzStatistics getStatistics() {
		Map.Entry<String, Integer> mostUsedEntry = requestCounts.entrySet().stream().max(Map.Entry.comparingByValue())
				.orElse(null);
		if (mostUsedEntry != null) {
			return new FizzBuzzStatistics(mostUsedEntry.getKey(), mostUsedEntry.getValue());
		} else {
			return new FizzBuzzStatistics(null, 0);
		}
	}

	public void updateStatistics(FizzBuzzRequest fizzBuzzRequest) {
		String requestKey = fizzBuzzRequest.getInt1() + "-" + fizzBuzzRequest.getInt2() + "-" + fizzBuzzRequest.getStr1() + "-" + fizzBuzzRequest.getStr2();
		requestCounts.put(requestKey, requestCounts.getOrDefault(requestKey, 0) + 1);
	}

}
