package com.fizzbuzz.FizzBuzz;

//@Configuration
public class SwaggerConfig {

//    @Bean
//    public Docket api() {
//        return new Docket(DocumentationType.OAS_30)
//            .select()
//            .apis(RequestHandlerSelectors.basePackage("com.fizzbuzz.FizzBuzz")) // Replace with your controller package
//            .paths(PathSelectors.any())
//            .build();
//    }
}
