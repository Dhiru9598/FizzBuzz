package com.fizzbuzz.FizzBuzz;

public class FizzBuzzStatistics {
	private String mostUsedRequest;
	private int numberOfHits;

	public FizzBuzzStatistics(String mostUsedRequest, int numberOfHits) {
		this.mostUsedRequest = mostUsedRequest;
		this.numberOfHits = numberOfHits;
	}

	public String getMostUsedRequest() {
		return mostUsedRequest;
	}

	public int getNumberOfHits() {
		return numberOfHits;
	}
}
